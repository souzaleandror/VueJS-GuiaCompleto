<template>
    <div>
        <h2>Contador Vue</h2>
        <hr>
    </div>
</template>

<style scoped>
    div {
        border: 1px solid green;
    }
</style>

