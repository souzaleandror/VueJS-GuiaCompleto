<template>
    <div class="alert alert-danger">Home</div>
</template>
