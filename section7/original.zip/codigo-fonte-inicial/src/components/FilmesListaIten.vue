<template>
    <li class="list-group-item">
        <span>Vingadores: Guerra Infinita</span>
        <button class="btn btn-success float-right">Editar</button>
    </li>
</template>
