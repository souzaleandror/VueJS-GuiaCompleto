<template>
    <div>
        <h2>Editar filme</h2>

        <div class="form-group">
            <label>Título:</label>
            <input type="text" class="form-control" placeholder="Insira o título">
        </div>
        
    </div>
</template>
